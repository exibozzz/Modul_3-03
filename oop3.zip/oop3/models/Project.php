<?php


    class Project
    {
        public $projectName;
        public $deadline;

        public function __construct($projectName, $deadline) {
        $this->projectName = $projectName;
        $this->deadline = $deadline;
    }

        public function getProjectDetails()
        {
            echo "Project: " . $this->projectName . ", Deadline: " . $this->deadline . "\n";
        }
    }