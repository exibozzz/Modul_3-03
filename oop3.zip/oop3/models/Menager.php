<?php


    class Menager extends Employee {
        public $menagedDepartment;

        public function __construct($id, $name, $salary, $menagedDepartment) {
            parent::__construct($id, $name, $salary);
            $this->menagedDepartment = $menagedDepartment;
        }

        public function getManagerInfo() {
            echo " • Menager id: {$this->id} </br> • Menager Name: {$this->name} </br> • Menager Salary: {$this->salary} </br> • Department: {$this->menagedDepartment} </br> <hr> ";
        }
    }