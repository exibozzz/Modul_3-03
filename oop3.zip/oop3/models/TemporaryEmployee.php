<?php


    class TemporaryEmployee extends Employee {
        public $contractEndDate;

        public function __construct($id, $name, $salary, $contractEndDate) {
            parent::__construct($id, $name, $salary);
            $this->contractEndDate = $contractEndDate;

        }

        public function getTemporaryContractInfo() {
            echo " • Employee ID: {$this->id} </br> • Name: {$this->name} </br> • Salary: {$this->salary} </br> • Contract ends on: {$this->contractEndDate} </br> <hr>"  ;
        }


    }
