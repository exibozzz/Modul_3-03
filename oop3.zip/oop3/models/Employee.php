<?php

    class Employee {
        public $id;
        public $name;
        public $salary;



        public function __construct($id, $name, $salary) {
            $this->id = $id;
            $this->name = $name;
            $this->salary = $salary;
        }

        public function employeeInformation() {
            echo "Employee id:" .$this->id. "Employee Name: " . $this->name . ", Salary: $" . $this->salary . "\n";
        }

    }