<?php

    // Parent class
    class FullTimeEmployee extends Employee
    {
        public $benefits;

        public function __construct($id, $name, $salary, $benefits){
            parent::__construct($id, $name, $salary);
            $this->benefits = $benefits;
        }

            public function getFullContractInfo() {
                echo "• Employee ID: {$this->id} </br> • Name: {$this->name} </br> • Salary: {$this->salary} </br> • Benefits: {$this->benefits} </br> <hr>";
            }
    }