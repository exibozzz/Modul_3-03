<?php



    class dbConnection{

        const HOST = "localhost";
        const DB_USER = "host";
        const DB_PASSWORD = "";
        const DB_NAME = "web_shop";

        public $dbConnection;

        public function __construct()
        {
            $this->dbConnection = mysqli_connect(self::HOST, self::DB_USER, self::DB_PASSWORD, self::DB_NAME);

            if (!$this->dbConnection) {
                    die("Connection failed: " . mysqli_connect_error());
                }
        }

    }