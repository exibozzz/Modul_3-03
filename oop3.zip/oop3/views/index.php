<?php

    require_once "../models/Employee.php";
    require_once "../models/TemporaryEmployee.php";
    require_once "../models/FullTimeEmployee.php";
    require_once "../models/Menager.php";
    require_once "../models/Project.php";

    $elonMusk = new TemporaryEmployee(1,"Elon Musk", 850, "02-02-2024");
    $jeffBezzos = new FullTimeEmployee(2, "Jeff Bezzos", 1035, "Travel in Greece 7 days");
    $steveJobs = new Menager(3, "Steve Jobs", 1200, "IT");

    $elonMusk->getTemporaryContractInfo();
    $jeffBezzos->getFullContractInfo();
    $steveJobs->getManagerInfo();










    ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>



</body>
</html>
